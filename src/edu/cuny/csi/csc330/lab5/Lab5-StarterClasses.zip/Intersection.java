/**
 * Class that represents a Street Corner 
 * Instances of this Class will be used to track the history and current location of DrunkWalker(s)
 */
package edu.cuny.csi.csc330.lab5;

public class Intersection {
	
	private int avenue;
	private int street; 

	public Intersection() {
		
	}
	// !!!!!!!!!!!!!!!!!  
	/**
	 * Constructor that takes ave and street values as parameters ... 
	 */
	
	
	/**
	 * toString() method  !!!!!!!!!!!!!!!!!
	 */
	
	
	
	/**
	 * Getters/Setters !!!!!!!!!!!!!!!!!!!
	 */
	
	

	/**
	 * hashCode() and equals() methods 
	 */
	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// Implement a Testing main()   !!!!!!!!!!!!!!!!
		// create 2 instances , populate, display, compare  ... does everything look sane??

	}

}
